 printjson(db.people.findOne({"nationality" : "China","sex" : "Female"}).toArray())
