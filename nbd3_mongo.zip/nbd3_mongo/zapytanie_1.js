printjson(db.people.findOne().toArray())
